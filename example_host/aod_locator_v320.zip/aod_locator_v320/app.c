/***************************************************************************//**
 * @file
 * @brief AoA locator application.
 *******************************************************************************
 * # License
 * <b>Copyright 2021 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * SPDX-License-Identifier: Zlib
 *
 * The licensor of this software is Silicon Laboratories Inc.
 *
 * This software is provided 'as-is', without any express or implied
 * warranty. In no event will the authors be held liable for any damages
 * arising from the use of this software.
 *
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, and to alter it and redistribute it
 * freely, subject to the following restrictions:
 *
 * 1. The origin of this software must not be misrepresented; you must not
 *    claim that you wrote the original software. If you use this software
 *    in a product, an acknowledgment in the product documentation would be
 *    appreciated but is not required.
 * 2. Altered source versions must be plainly marked as such, and must not be
 *    misrepresented as being the original software.
 * 3. This notice may not be removed or altered from any source distribution.
 *
 ******************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "sl_bt_api.h"
#include "ncp_host.h"
#include "app_log.h"
#include "app_assert.h"
#include "app.h"
#include "mqtt.h"
#include "app_config.h"

#include "conn.h"
#include "aoa_config.h"
#include "aoa_parse.h"
#include "aoa_serdes.h"
#include "aoa_util.h"
#ifdef AOD_ANGLE
#include "aoa_angle.h"
#include "aoa_angle_config.h"
#endif // AOD_ANGLE

// Optstring argument for getopt.
#define OPTSTRING      NCP_HOST_OPTSTRING "m:c:v:h"

// Usage info.
#define USAGE          "\n%s " NCP_HOST_USAGE " [-m <mqtt_address>[:<port>]] [-c <config>] [-v <level>] [-h]\n"

// Options info.
#define OPTIONS                                                                                         \
  "\nOPTIONS\n"                                                                                         \
  NCP_HOST_OPTIONS                                                                                      \
  "    -m  MQTT broker connection parameters.\n"                                                        \
  "        <mqtt_address>   Address of the MQTT broker (default: localhost)\n"                          \
  "        <port>           Port of the MQTT broker (default: 1883)\n"                                  \
  "    -c  Locator configuration file.\n"                                                               \
  "        <config>         Path to the configuration file\n"                                           \
  "    -v  Verbosity level.\n"                                                                          \
  "        <level>          1 to display message when ignoring tag not on the allowlist (default: 0)\n" \
  "    -h  Print this help message.\n"

static void parse_config(char *filename);

// #ifdef AOD_ANGLE
// static void on_message(mqtt_handle_t *handle, const char *topic, const char *payload);
// static void subscribe_correction(void);
// #endif // AOD_ANGLE

// Locator ID
static aoa_id_t tagAsset_id;

// MQTT variables
// static mqtt_handle_t mqtt_handle = MQTT_DEFAULT_HANDLE;
// static char *mqtt_host = NULL;

// Verbose output
uint32_t verbose_level = 0;



#if 1  // Cheng

// -----------------------------------------------------------------------------
// Private macros

#define INVALID_IDX              UINT32_MAX

#define CHECK_ERROR(x)           if ((x) != SL_RTL_ERROR_SUCCESS) return (x)

// #define USAGE                    "\nUsage: %s -c <config> [-m <address>[:<port>]]\n"

enum axis_list {
  AXIS_X,
  AXIS_Y,
  AXIS_Z,
  AXIS_COUNT
};

// -----------------------------------------------------------------------------
// Private types

typedef struct {
  aoa_id_t id;
  struct sl_rtl_loc_locator_item item;
} aoa_locator_t;

typedef struct {
  aoa_id_t id;
  uint32_t loc_id[MAX_NUM_LOCATORS]; // assigned by RTL lib
  sl_rtl_loc_libitem loc;
  sl_rtl_util_libitem filter[AXIS_COUNT];
  aoa_angle_t angle[MAX_NUM_LOCATORS];
  bool ready[MAX_NUM_LOCATORS];
  aoa_position_t position;
} aoa_asset_tag_t;

// -----------------------------------------------------------------------------
// Private variables

//static mqtt_handle_t mqtt_handle = MQTT_DEFAULT_HANDLE;

static aoa_locator_t locator_list[MAX_NUM_LOCATORS];
static aoa_asset_tag_t asset_tag_list[MAX_NUM_TAGS];

static uint32_t locator_count = 0;
static uint32_t asset_tag_count = 0;

static aoa_id_t multilocator_id = "";

// static int serial_port_init(char* uartPort, uint32_t uartBaudRate, uint32_t uartFlowControl, int32_t timeout);
// static void uart_tx_wrapper(uint32_t len, uint8_t *data);
// static void tcp_tx_wrapper(uint32_t len, uint8_t *data);
static void parse_config(char *filename);
static void on_message(const char *topic, const char *payload);
static void publish_position(aoa_asset_tag_t *tag);
static bool is_ready(aoa_asset_tag_t *tag);
static enum sl_rtl_error_code run_estimation(aoa_asset_tag_t *tag);
static enum sl_rtl_error_code init_asset_tag(aoa_asset_tag_t *tag, aoa_id_t id);
static uint32_t find_asset_tag(aoa_id_t id);
static uint32_t find_locator(aoa_id_t id);

#endif





/**************************************************************************//**
 * Application Init.
 *****************************************************************************/
void app_init(int argc, char *argv[])
{
  sl_status_t sc;
  int opt;
  // char *port_str;

  aoa_allowlist_init();

  // Process command line options.
  while ((opt = getopt(argc, argv, OPTSTRING)) != -1) {
    switch (opt) {
      // MQTT broker connection parameters.
      // case 'm':
      //   strtok(optarg, ":");
      //   mqtt_host = malloc(strlen(optarg) + 1);
      //   if (mqtt_host != NULL) {
      //     strcpy(mqtt_host, optarg);
      //     mqtt_handle.host = mqtt_host;
      //   }
      //   port_str = strtok(NULL, ":");
      //   if (port_str != NULL) {
      //     mqtt_handle.port = atoi(port_str);
      //   }
      //   break;
      // Locator configuration file.
      case 'c':
        parse_config(optarg);
        break;
      // Verbosity level.
      case 'v':
        verbose_level = atol(optarg);
        break;
      // Print help.
      case 'h':
        app_log(USAGE, argv[0]);
        app_log(OPTIONS);
        exit(EXIT_SUCCESS);

      // Process options for other modules.
      default:
        sc = ncp_host_set_option((char)opt, optarg);
        if (sc != SL_STATUS_OK) {
          app_log(USAGE, argv[0]);
          exit(EXIT_FAILURE);
        }
        break;
    }
  }

  // Initialize NCP connection.
  sc = ncp_host_init();
  if (sc == SL_STATUS_INVALID_PARAMETER) {
    app_log(USAGE, argv[0]);
    exit(EXIT_FAILURE);
  }
  app_assert_status(sc);
  app_log_info("NCP host initialised." APP_LOG_NEW_LINE);
  app_log_info("Resetting NCP target..." APP_LOG_NEW_LINE);
  // Reset NCP to ensure it gets into a defined state.
  // Once the chip successfully boots, boot event should be received.
  sl_bt_system_reset(sl_bt_system_boot_mode_normal);

  init_connection();
  app_log_info("Press Crtl+C to quit" APP_LOG_NEW_LINE APP_LOG_NEW_LINE);
}

/**************************************************************************//**
 * Application Process Action.
 *****************************************************************************/
void app_process_action(void)
{
  // mqtt_step(&mqtt_handle);
}

/**************************************************************************//**
 * Application Deinit.
 *****************************************************************************/
void app_deinit(void)
{
  app_log("Shutting down.\n");
  ncp_host_deinit();
  // mqtt_deinit(&mqtt_handle);
  // if (mqtt_host != NULL) {
  //   free(mqtt_host);
  // }
}

/**************************************************************************//**
 * Bluetooth stack event handler.
 * This overrides the dummy weak implementation.
 *
 * @param[in] evt Event coming from the Bluetooth stack.
 *****************************************************************************/
void sl_bt_on_event(sl_bt_msg_t *evt)
{
  sl_status_t sc;
  // mqtt_status_t rc;
  bd_addr address;
  uint8_t address_type;

  // Catch boot event...
  if (SL_BT_MSG_ID(evt->header) == sl_bt_evt_system_boot_id) {
    // Print boot message.
    app_log("Bluetooth stack booted: v%d.%d.%d-b%d\n",
            evt->data.evt_system_boot.major,
            evt->data.evt_system_boot.minor,
            evt->data.evt_system_boot.patch,
            evt->data.evt_system_boot.build);
    // Extract unique ID from BT Address.
    sc = sl_bt_system_get_identity_address(&address, &address_type);
    app_assert(sc == SL_STATUS_OK,
               "[E: 0x%04x] Failed to get Bluetooth address\n",
               (int)sc);
    app_log("Bluetooth %s address: %02X:%02X:%02X:%02X:%02X:%02X\n",
            address_type ? "static random" : "public device",
            address.addr[5],
            address.addr[4],
            address.addr[3],
            address.addr[2],
            address.addr[1],
            address.addr[0]);

    // in the case of aod, here the locator_id is the address of the tag itself,
    // however, we didn't use the mqtt in the aod_locator host application
    // so, please just ignore the locator_id here, the others have a different meaning with this one.
    aoa_address_to_id(address.addr, address_type, tagAsset_id);
    app_log("aod debug, the tag address is %s \r\n", tagAsset_id);

    // Connect to the MQTT broker
    // mqtt_handle.client_id = tagAsset_id;
    // mqtt_handle.on_connect = aoa_on_connect;
    // rc = mqtt_init(&mqtt_handle);
    // app_assert(rc == MQTT_SUCCESS, "MQTT init failed.\n");

// #ifdef AOD_ANGLE
//     mqtt_handle.on_message = on_message;
//     subscribe_correction();
// #endif // AOD_ANGLE
  }
  // ...then call the connection specific event handler.
  app_bt_on_event(evt);
}

#if 0
#ifdef AOD_ANGLE
/**************************************************************************//**
 * Subscribe for angle feedback messages from the multilocator.
 *****************************************************************************/
static void subscribe_correction(void)
{
  const char topic_template[] = AOA_TOPIC_CORRECTION_PRINT;
  char topic[sizeof(topic_template) + sizeof(aoa_id_t) + 1];
  mqtt_status_t rc;

  snprintf(topic, sizeof(topic), topic_template, tagAsset_id, "+");

  app_log("Subscribing to topic '%s'.\n", topic);

  rc = mqtt_subscribe(&mqtt_handle, topic);
  app_assert(rc == MQTT_SUCCESS, "Failed to subscribe to topic '%s'.\n", topic);
}

/**************************************************************************//**
 * MQTT message arrived callback.
 *****************************************************************************/
static void on_message(mqtt_handle_t *handle, const char *topic, const char *payload)
{
  int result;
  aoa_id_t loc_id, tag_id;
  aoa_correction_t correction;
  bd_addr tag_addr;
  uint8_t tag_addr_type;
  conn_properties_t *tag = NULL;
  enum sl_rtl_error_code ec;
  sl_status_t sc;

  (void)handle;

  // Parse topic
  result = sscanf(topic, AOA_TOPIC_CORRECTION_SCAN, loc_id, tag_id);
  app_assert(result == 2, "Failed to parse correction topic: %d.\n", result);

  if (aoa_id_compare(loc_id, tag_id) != 0) {
    // Accidentally got a wrong message
    return;
  }
  // Find asset tag in the database
  sc = aoa_id_to_address(tag_id, tag_addr.addr, &tag_addr_type);
  if (SL_STATUS_OK == sc) {
    tag = get_connection_by_address(&tag_addr);
  }
  if (tag != NULL) {
    // Parse payload
    sc = aoa_deserialize_correction((char *)payload, &correction);
    app_assert(sc == SL_STATUS_OK,
               "[E: 0x%04x] aoa_deserialize_correction failed\n",
               (int)sc);

    if (aoa_sequence_compare(tag->sequence, correction.sequence) <= MAX_CORRECTION_DELAY) {
      app_log("Apply correction #%d for asset tag '%s'\n", correction.sequence, tag_id);
      ec = aoa_set_correction(&tag->aoa_state, &correction);
      app_assert(ec == SL_RTL_ERROR_SUCCESS,
                 "[E: %d] Failed to set correction values\n", ec);
    } else {
      app_log("Omit correction #%d for asset tag '%s'\n", correction.sequence, tag_id);
    }
  }
}
#endif // AOD_ANGLE
#endif

/**************************************************************************//**
 * IQ report callback.
 *****************************************************************************/
void app_on_iq_report(conn_properties_t *locator, aoa_iq_report_t *iq_report)
{
  aoa_id_t locator_id;
  // mqtt_status_t rc;
  char *payload;
  sl_status_t sc;

#ifndef AOD_ANGLE
  const char topic_template[] = AOA_TOPIC_IQ_REPORT_PRINT;

  // Compile payload
  sc = aoa_serialize_iq_report(iq_report, &payload);
#else
  enum sl_rtl_error_code ec;
  aoa_angle_t angle;
  const char topic_template[] = AOA_TOPIC_ANGLE_PRINT;

  ec = aoa_calculate(&locator->aoa_state, iq_report, &angle);
  if (ec == SL_RTL_ERROR_ESTIMATION_IN_PROGRESS) {
    // No valid angles are available yet.
    return;
  }
  app_assert(ec == SL_RTL_ERROR_SUCCESS,
             "[E: %d] Failed to calculate angle\n", ec);

  // Store the latest sequence number for the locator.
  locator->sequence = iq_report->event_counter;

  // Compile payload
  sc = aoa_serialize_angle(&angle, &payload);

  app_log("azimuth: %6.1f  \televation: %6.1f  \trssi: %6.0f  \tch: %2d  \tSequence: %5d  \tDistance: %6.3f  \t",
          angle.azimuth, angle.elevation, iq_report->rssi / 1.0, iq_report->channel, iq_report->event_counter, angle.distance, angle.quality);

  // Check the IQ sample quality result and present a short string according to it
  char *iq_sample_qa_string;
  if (angle.quality == 0) {
    iq_sample_qa_string = "Good                                   ";
  } else if (SL_RTL_AOX_IQ_SAMPLE_QA_IS_SET(angle.quality, SL_RTL_AOX_IQ_SAMPLE_QA_REF_ANT_PHASE_JITTER)
              || SL_RTL_AOX_IQ_SAMPLE_QA_IS_SET(angle.quality, SL_RTL_AOX_IQ_SAMPLE_QA_ANT_X_PHASE_JITTER)) {
    iq_sample_qa_string = "Caution - phase jitter too large       ";
  } else if (SL_RTL_AOX_IQ_SAMPLE_QA_IS_SET(angle.quality, SL_RTL_AOX_IQ_SAMPLE_QA_SNDR)) {
    iq_sample_qa_string = "Caution - reference period SNDR too low";
  } else {
    iq_sample_qa_string = "Caution (other)                        ";
  }
  app_log("IQ sample Quality: %s \r\n", iq_sample_qa_string);

#endif // AOD_ANGLE
  app_assert(sc == SL_STATUS_OK,
             "[E: 0x%04x] Failed to serialize the payload.\n",
             (int)sc);

  // Compile topic
  char topic[sizeof(topic_template) + sizeof(aoa_id_t) + sizeof(aoa_id_t)];
  aoa_address_to_id(locator->address.addr, locator->address_type, locator_id);
  snprintf(topic, sizeof(topic), topic_template, tagAsset_id, locator_id);

#if 1 // Cheng
  // Send message
  on_message(topic, payload);
#else
  // Send message
  rc = mqtt_publish(&mqtt_handle, topic, payload);
  app_assert(rc == MQTT_SUCCESS, "Failed to publish to topic '%s'.\n", topic);
#endif
  // Clean up
  free(payload);
}


#if 1 //Cheng

static void on_message(const char *topic, const char *payload)
{
  int result;
  aoa_id_t loc_id, tag_id;
  uint32_t loc_idx, tag_idx;
  aoa_asset_tag_t *tag;
  enum sl_rtl_error_code sc;

  // Parse topic.
  result = sscanf(topic, AOA_TOPIC_ANGLE_SCAN, tag_id, loc_id);
  app_assert(result == 2, "Failed to parse angle topic: %d.\n", result);

  // Find locator.
  loc_idx = find_locator(loc_id);
  app_assert(loc_idx != INVALID_IDX, "Failed to find locator %s.\n", loc_id);

  // Find asset tag.
  tag_idx = find_asset_tag(tag_id);


  if (tag_idx == INVALID_IDX) {
    if (asset_tag_count < MAX_NUM_TAGS) {
      // Add new tag
      // app_log("evt, on_message #2.\n");
      sc = init_asset_tag(&asset_tag_list[asset_tag_count], tag_id);
      app_assert(sc == SL_RTL_ERROR_SUCCESS,
                 "[E: 0x%04x] Failed to init asset tag %s.\n", sc, tag_id);
      app_log("New tag added (gg %d): %s\n", asset_tag_count, tag_id);
      tag_idx = asset_tag_count++;
    } else {
      app_log("Warning! Maximum number of asset tags reached: %d\n", asset_tag_count);
      // No further procesing possible.
      return;
    }
  }

  // app_log("evt, on_message #3.\n");
  // Create shortcut.
  tag = &asset_tag_list[tag_idx];

  // Parse payload and get the angle calculated with the given locator.
  // 每一个tag可以对多个locator的beacon进行IQ sample，并计算得出angle值。
  // 因此需要收集所有locator对应的angle数据，然后计算得出tag的position信息。
  aoa_deserialize_angle((char *)payload, &tag->angle[loc_idx]);

  tag->ready[loc_idx] = true;

  // app_log("evt, on_message #4.\n");

  // Run estimation and publish results.
  if (is_ready(tag)) {
    // app_log("evt, on_message #5.\n");
    sc = run_estimation(tag);
    app_assert(sc == SL_RTL_ERROR_SUCCESS,
               "[E: 0x%04x] Position estimation failed for %s.\n", sc, tag->id);
    // app_log("evt, on_message #6.\n");
    publish_position(tag);
  }
}

/**************************************************************************//**
 * Publish position of a given tag.
 *****************************************************************************/
static void publish_position(aoa_asset_tag_t *tag)
{
  sl_status_t sc;
  // mqtt_status_t rc;
  char *payload;
  // const char topic_template[] = AOA_TOPIC_POSITION_PRINT;
  // char topic[sizeof(topic_template) + sizeof(aoa_id_t) + sizeof(aoa_id_t)];

  // Compile topic.
  // snprintf(topic, sizeof(topic), topic_template, multilocator_id, tag->id);

  app_log("tag->position x= %f, y= %f, z=%f, sequence %d \r\n", tag->position.x, tag->position.y, tag->position.z, tag->position.sequence);
  // Compile payload.
  sc = aoa_serialize_position(&tag->position, &payload);
  app_assert(sc == SL_STATUS_OK,
             "[E: 0x%04x] aoa_serialize_position failed.\n",
             (int)sc);

  printf("%s\r\n", payload);

  //rc = mqtt_publish(&mqtt_handle, topic, payload);
  //app_assert(rc == MQTT_SUCCESS, "Failed to publish to topic '%s'.\n", topic);
  // Clean up.
  free(payload);
}

/**************************************************************************//**
 * Check if all data are ready for a tag to run estimation.
 *****************************************************************************/
static bool is_ready(aoa_asset_tag_t *tag)
{
  for (uint32_t i = 0; i < locator_count; i++) {
    if (tag->ready[i] == false) {
      return false;
    }
  }
  return true;
}

/**************************************************************************//**
 * Run position estimation algorithm for a given asset tag.
 *****************************************************************************/
static enum sl_rtl_error_code run_estimation(aoa_asset_tag_t *tag)
{
  enum sl_rtl_error_code sc;

  // Feed measurement values into RTL lib.
  for (uint32_t i = 0; i < locator_count; i++) {
    sc = sl_rtl_loc_set_locator_measurement(&tag->loc,
                                            tag->loc_id[i],
                                            SL_RTL_LOC_LOCATOR_MEASUREMENT_AZIMUTH,
                                            tag->angle[i].azimuth);
    CHECK_ERROR(sc);

    sc = sl_rtl_loc_set_locator_measurement(&tag->loc,
                                            tag->loc_id[i],
                                            SL_RTL_LOC_LOCATOR_MEASUREMENT_ELEVATION,
                                            tag->angle[i].elevation);
    CHECK_ERROR(sc);

    // Feeding RSSI distance measurement to the RTL library improves location
    // accuracy when the measured distance is reasonably correct.
    // If the received signal strength of the incoming signal is altered for any
    // other reason than the distance between the TX and RX itself, it will lead
    // to incorrect measurement and it will lead to incorrect position estimates.
    // For this reason the RSSI distance usage is disabled by default in the
    // multilocator case.
    // Single locator mode however always requires the distance measurement in
    // addition to the angle, please note the if-condition below.
    // In case the distance estimation should be used in the  multilocator case,
    // you can enable it by commenting out the condition.
    if (locator_count == 1) {
      sc = sl_rtl_loc_set_locator_measurement(&tag->loc,
                                              tag->loc_id[i],
                                              SL_RTL_LOC_LOCATOR_MEASUREMENT_DISTANCE,
                                              tag->angle[i].distance);
      CHECK_ERROR(sc);
    }
    tag->ready[i] = false;
  }

  // Process new measurements, time step given in seconds.
  sc = sl_rtl_loc_process(&tag->loc, ESTIMATION_INTERVAL_SEC);
  CHECK_ERROR(sc);

  // Get results from the estimator.
  sc = sl_rtl_loc_get_result(&tag->loc, SL_RTL_LOC_RESULT_POSITION_X, &tag->position.x);
  CHECK_ERROR(sc);
  sc = sl_rtl_loc_get_result(&tag->loc, SL_RTL_LOC_RESULT_POSITION_Y, &tag->position.y);
  CHECK_ERROR(sc);
  sc = sl_rtl_loc_get_result(&tag->loc, SL_RTL_LOC_RESULT_POSITION_Z, &tag->position.z);
  CHECK_ERROR(sc);

  // Apply filter on the result.
  sc = sl_rtl_util_filter(&tag->filter[AXIS_X], tag->position.x, &tag->position.x);
  CHECK_ERROR(sc);
  sc = sl_rtl_util_filter(&tag->filter[AXIS_Y], tag->position.y, &tag->position.y);
  CHECK_ERROR(sc);
  sc = sl_rtl_util_filter(&tag->filter[AXIS_Z], tag->position.z, &tag->position.z);
  CHECK_ERROR(sc);

  // Clear measurements.
  sc = sl_rtl_loc_clear_measurements(&tag->loc);
  CHECK_ERROR(sc);

  return SL_RTL_ERROR_SUCCESS;
}

/**************************************************************************//**
 * Initialise a new asset tag.
 *****************************************************************************/
static enum sl_rtl_error_code init_asset_tag(aoa_asset_tag_t *tag, aoa_id_t id)
{
  enum sl_rtl_error_code sc;

  aoa_id_copy(tag->id, id);

  // Initialize RTL library
  sc = sl_rtl_loc_init(&tag->loc);
  CHECK_ERROR(sc);

  // Select estimation mode.
  sc = sl_rtl_loc_set_mode(&tag->loc, ESTIMATION_MODE);
  CHECK_ERROR(sc);

  // Provide locator configurations to the position estimator.
  for (uint32_t i = 0; i < locator_count; i++) {
    // Add a locator item into the locationing estimator after setting its position and orientation parameters.
    // The locator item was set during the initial stage by parsing the configuration file
    // This function will assign a ID for the locator which is tag->locat_id[i].
    sc = sl_rtl_loc_add_locator(&tag->loc, &locator_list[i].item, &tag->loc_id[i]);
    CHECK_ERROR(sc);
    tag->ready[i] = false;
  }

  // Create position estimator.
  sc = sl_rtl_loc_create_position_estimator(&tag->loc);
  CHECK_ERROR(sc);

  // Initialize util functions.
  for (enum axis_list i = 0; i < AXIS_COUNT; i++) {
    sc = sl_rtl_util_init(&tag->filter[i]);
    CHECK_ERROR(sc);
    // Set position filtering parameter for every axis.
    sc = sl_rtl_util_set_parameter(&tag->filter[i],
                                   SL_RTL_UTIL_PARAMETER_AMOUNT_OF_FILTERING,
                                   FILTERING_AMOUNT);
    CHECK_ERROR(sc);
  }

  return SL_RTL_ERROR_SUCCESS;
}

/**************************************************************************//**
 * Find asset tag in the local list based on its ID.
 *****************************************************************************/
static uint32_t find_asset_tag(aoa_id_t id)
{
  uint32_t retval = INVALID_IDX;

  for (uint32_t i = 0; (i < asset_tag_count) && (retval == INVALID_IDX); i++) {
    if (aoa_id_compare(asset_tag_list[i].id, id) == 0) {
      retval = i;
    }
  }
  return retval;
}

/**************************************************************************//**
 * Find locator in the local list based on its ID.
 *****************************************************************************/
static uint32_t find_locator(aoa_id_t id)
{
  uint32_t retval = INVALID_IDX;

  for (uint32_t i = 0; (i < locator_count) && (retval == INVALID_IDX); i++) {
    if (aoa_id_compare(locator_list[i].id, id) == 0) {
      retval = i;
    }
  }
  return retval;
}

#endif



/**************************************************************************//**
 * Configuration file parser
 *****************************************************************************/
static void parse_config(char *filename)
{
  sl_status_t sc;
  char *buffer;

  aoa_locator_t *loc;
  // aoa_id_t id;
  // uint8_t address[ADR_LEN], address_type;

  buffer = load_file(filename);
  app_assert(buffer != NULL, "Failed to load file: %s\n", filename);

  sc = aoa_parse_init(buffer);
  app_assert(sc == SL_STATUS_OK,
             "[E: 0x%04x] aoa_parse_init failed\n",
             (int)sc);

#ifdef AOD_ANGLE

  sc = aoa_parse_multilocator(multilocator_id);
  app_assert(sc == SL_STATUS_OK,
             "[E: 0x%04x] aoa_parse_multilocator failed\n",
             (int)sc);

  // sc = aoa_parse_azimuth(&aoa_azimuth_min, &aoa_azimuth_max);
  // app_assert((sc == SL_STATUS_OK) || (sc == SL_STATUS_NOT_FOUND),
  //            "[E: 0x%04x] aoa_parse_azimuth failed\n",
  //            (int)sc);
#endif // AOD_ANGLE

  do {
    loc = &locator_list[locator_count];
    sc = aoa_parse_locator(loc->id, &loc->item);
    if (sc == SL_STATUS_OK) {
      app_log("Locator added: id: %s, coordinate: %f %f %f, orientation: %f %f %f\n",
              loc->id,
              loc->item.coordinate_x,
              loc->item.coordinate_y,
              loc->item.coordinate_z,
              loc->item.orientation_x_axis_degrees,
              loc->item.orientation_y_axis_degrees,
              loc->item.orientation_z_axis_degrees);
      ++locator_count;
    } else {
      app_assert(sc == SL_STATUS_NOT_FOUND,
                 "[E: 0x%04x] aoa_parse_locator failed\n",
                 (int)sc);
    }
  } while ((locator_count < MAX_NUM_LOCATORS) && (sc == SL_STATUS_OK));

  app_log("Locator count: %d\n", locator_count);

#if 0  // Cheng
  do {
    sc = aoa_parse_allowlist(address, &address_type);
    if (sc == SL_STATUS_OK) {
      aoa_address_to_id(address, address_type, id);
      app_log("Adding tag id '%s' to the allowlist.\n", id);
      sc = aoa_allowlist_add(address);
    } else {
      app_assert(sc == SL_STATUS_NOT_FOUND,
                 "[E: 0x%04x] aoa_parse_allowlist failed\n",
                 (int)sc);
    }
  } while (sc == SL_STATUS_OK);
#endif

  sc = aoa_parse_deinit();
  app_assert(sc == SL_STATUS_OK,
             "[E: 0x%04x] aoa_parse_deinit failed\n",
             (int)sc);

  free(buffer);
}
