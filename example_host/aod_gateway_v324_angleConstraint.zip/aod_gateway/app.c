/***************************************************************************//**
 * @file
 * @brief AoA locator application.
 *******************************************************************************
 * # License
 * <b>Copyright 2021 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * SPDX-License-Identifier: Zlib
 *
 * The licensor of this software is Silicon Laboratories Inc.
 *
 * This software is provided 'as-is', without any express or implied
 * warranty. In no event will the authors be held liable for any damages
 * arising from the use of this software.
 *
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, and to alter it and redistribute it
 * freely, subject to the following restrictions:
 *
 * 1. The origin of this software must not be misrepresented; you must not
 *    claim that you wrote the original software. If you use this software
 *    in a product, an acknowledgment in the product documentation would be
 *    appreciated but is not required.
 * 2. Altered source versions must be plainly marked as such, and must not be
 *    misrepresented as being the original software.
 * 3. This notice may not be removed or altered from any source distribution.
 *
 ******************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "sl_bt_api.h"
#include "ncp_host.h"
#include "app_log.h"
#include "app_assert.h"
#include "app.h"
#include "mqtt.h"
#include "app_config.h"

#include "conn.h"
#include "aoa_config.h"
#include "aoa_parse.h"
#include "aoa_serdes.h"
#include "aoa_util.h"
#ifdef AOA_ANGLE
#include "aoa_angle.h"
#include "aoa_angle_config.h"
#endif // AOA_ANGLE


#ifndef USE_OLD_ALGORITHM
#define USE_OLD_ALGORITHM
#endif


// Optstring argument for getopt.
#define OPTSTRING      NCP_HOST_OPTSTRING "m:c:v:h"

// Usage info.
#define USAGE          "\n%s " NCP_HOST_USAGE " [-m <mqtt_address>[:<port>]] [-c <config>] [-v <level>] [-h]\n"

// Options info.
#define OPTIONS                                                                                         \
  "\nOPTIONS\n"                                                                                         \
  NCP_HOST_OPTIONS                                                                                      \
  "    -m  MQTT broker connection parameters.\n"                                                        \
  "        <mqtt_address>   Address of the MQTT broker (default: localhost)\n"                          \
  "        <port>           Port of the MQTT broker (default: 1883)\n"                                  \
  "    -c  Locator configuration file.\n"                                                               \
  "        <config>         Path to the configuration file\n"                                           \
  "    -v  Verbosity level.\n"                                                                          \
  "        <level>          1 to display message when ignoring tag not on the allowlist (default: 0)\n" \
  "    -h  Print this help message.\n"

static void parse_config(char *filename);
#ifdef AOA_ANGLE
static void on_message(mqtt_handle_t *handle, const char *topic, const char *payload);
static void subscribe_correction(void);
#endif // AOA_ANGLE

// Locator ID
static aoa_id_t locator_id;

static aoa_id_t locatorxxd_id;

// MQTT variables
static mqtt_handle_t mqtt_handle = MQTT_DEFAULT_HANDLE;
static char *mqtt_host = NULL;

// Verbose output
uint32_t verbose_level = 0;


// -----------------------------------------------------------------------------
// Private macros

#define INVALID_IDX              UINT32_MAX

#define CHECK_ERROR(x)           if ((x) != SL_RTL_ERROR_SUCCESS) return (x)

#define ROUND_DIV(num, den)      (((num) + ((den) / 2)) / (den))

enum axis_list {
  AXIS_X,
  AXIS_Y,
  AXIS_Z,
  AXIS_COUNT
};

// #ifdef AOA_ANGLE
// #define SUBSCRIBE_TOPIC_SCAN   AOA_TOPIC_IQ_REPORT_SCAN
// #define SUBSCRIBE_TOPIC_PRINT  AOA_TOPIC_IQ_REPORT_PRINT
// #else
// #define SUBSCRIBE_TOPIC_SCAN   AOA_TOPIC_ANGLE_SCAN
// #define SUBSCRIBE_TOPIC_PRINT  AOA_TOPIC_ANGLE_PRINT
// #endif // AOA_ANGLE

// -----------------------------------------------------------------------------
// Private types
#ifdef USE_OLD_ALGORITHM

typedef struct {
  float aox_azimuth_min_mask;
  float aox_azimuth_max_mask;
} aox_azimuth_mask_t;

typedef struct {
  aoa_id_t id;
  struct sl_rtl_loc_locator_item item;
  aox_azimuth_mask_t aox_azimuth_mask;    // azimuth angle constraint min and max
} aoa_locator_t;

typedef struct {
  aoa_id_t id;
  uint32_t loc_id[MAX_NUM_LOCATORS]; // assigned by RTL lib
  sl_rtl_loc_libitem loc;
  sl_rtl_util_libitem filter[AXIS_COUNT];
  aoa_angle_t angle[MAX_NUM_LOCATORS];
  bool ready[MAX_NUM_LOCATORS];
  aoa_position_t position;
// #ifdef AOA_ANGLE
  // aoa_state_t aoa_state[MAX_NUM_LOCATORS];
// #endif // AOA_ANGLE  
} aoa_asset_tag_t;
#else
typedef struct {
  aoa_id_t id;
  struct sl_rtl_loc_locator_item item;
} aoa_locator_t;

typedef struct {
  int32_t sequence;
  int32_t num_angles;
  aoa_angle_t angles[MAX_NUM_LOCATORS];
  bool has_angle[MAX_NUM_LOCATORS];
} aoa_correlated_angles_t;

typedef struct {
  aoa_id_t id;
  uint32_t loc_id[MAX_NUM_LOCATORS]; // assigned by RTL lib
  sl_rtl_loc_libitem loc;
  sl_rtl_util_libitem filter[AXIS_COUNT];
  aoa_correlated_angles_t correlated_angles[MAX_NUM_SEQUENCE_IDS];
  aoa_position_t position;
#ifdef AOA_ANGLE
  aoa_state_t aoa_state[MAX_NUM_LOCATORS];
#endif // AOA_ANGLE
} aoa_asset_tag_t;
#endif
// -----------------------------------------------------------------------------
// Private variables

static uint32_t locator_count = 0;
static uint32_t asset_tag_count = 0;

static aoa_locator_t locator_list[MAX_NUM_LOCATORS];
static aoa_asset_tag_t asset_tag_list[MAX_NUM_TAGS];

static aoa_id_t multilocator_id = "";

#ifdef ENABLE_ANGLE_FEEDBACK
static bool enable_feedback = true;
#else
static bool enable_feedback = false;
#endif

static uint32_t expected_angles_count[MAX_NUM_SEQUENCE_IDS];

#ifdef USE_OLD_ALGORITHM
static void parse_config(char *filename);
static void on_message_cal_position(const char *topic, const char *payload);
static void publish_angle(const char *topic, const char *payload);
static void publish_position(aoa_asset_tag_t *tag);

static void set_correction(aoa_asset_tag_t *tag, uint32_t loc_idx, aoa_correction_t *correction);

static enum sl_rtl_error_code run_estimation(aoa_asset_tag_t *tag);
static enum sl_rtl_error_code init_asset_tag(aoa_asset_tag_t *tag, aoa_id_t id);
static uint32_t find_asset_tag(aoa_id_t id);
static uint32_t find_locator(aoa_id_t id);
static bool is_ready(aoa_asset_tag_t *tag);

#else
static void parse_config(char *filename);
static void on_message_cal_position(const char *topic, const char *payload);
static void subscribe_topic(aoa_locator_t *loc);
static void publish_position(aoa_asset_tag_t *tag);
static void set_correction(aoa_asset_tag_t *tag, uint32_t loc_idx, aoa_correction_t *correction);
static enum sl_rtl_error_code run_estimation(aoa_asset_tag_t *tag, uint32_t slot);
static enum sl_rtl_error_code init_asset_tag(aoa_asset_tag_t *tag, aoa_id_t id);
static uint32_t find_asset_tag(aoa_id_t id);
static uint32_t find_locator(aoa_id_t id);
static void init_expected_angle_counts(void);
static void init_correlated_angle_data(aoa_correlated_angles_t* angle);
static void add_angle_data_to_tag(aoa_asset_tag_t* tag, uint32_t loc_idx, aoa_angle_t* angle);
static int32_t find_angle_slot(aoa_correlated_angles_t* slots, int32_t sequence);
static void update_slots(aoa_asset_tag_t* tag, aoa_angle_t* angle, int32_t slot, uint32_t loc_idx);
static void push_completed_angle_data(aoa_asset_tag_t* tag, int32_t check_idx_from);
#endif

void get_azimuth_mask_by_locator_address(aoa_id_t id, float *min, float *max)
{
  uint32_t retval = INVALID_IDX;

  for (uint32_t i = 0; (i < locator_count) && (retval == INVALID_IDX); i++) {
    if (aoa_id_compare(locator_list[i].id, id) == 0) {
      *min =locator_list[i].aox_azimuth_mask.aox_azimuth_min_mask;
      *max =locator_list[i].aox_azimuth_mask.aox_azimuth_max_mask;
    }
  }
}


/**************************************************************************//**
 * Application Init.
 *****************************************************************************/
void app_init(int argc, char *argv[])
{
  mqtt_status_t rc;
  sl_status_t sc;
  int opt;
  char *port_str;

  aoa_allowlist_init();

  // Process command line options.
  while ((opt = getopt(argc, argv, OPTSTRING)) != -1) {
    switch (opt) {
      // MQTT broker connection parameters.
      case 'm':
        strtok(optarg, ":");
        mqtt_host = malloc(strlen(optarg) + 1);
        if (mqtt_host != NULL) {
          strcpy(mqtt_host, optarg);
          mqtt_handle.host = mqtt_host;
        }
        port_str = strtok(NULL, ":");
        if (port_str != NULL) {
          mqtt_handle.port = atoi(port_str);
        }
        break;
      // Locator configuration file.
      case 'c':
        parse_config(optarg);
        break;
      // Turn off the bad angle feedback feature.
      case 'n':
        enable_feedback = false;
        break;        
      // Verbosity level.
      case 'v':
        verbose_level = atol(optarg);
        break;
      // Print help.
      case 'h':
        app_log(USAGE, argv[0]);
        app_log(OPTIONS);
        exit(EXIT_SUCCESS);
      // Process options for other modules, like -u, -t, -b, -f
      default:
        sc = ncp_host_set_option((char)opt, optarg);
        if (sc != SL_STATUS_OK) {
          app_log(USAGE, argv[0]);
          exit(EXIT_FAILURE);
        }
        break;
    }
  }

  // multilocator_id is the value defined in multilocator_config.json file or specified by -m option
  mqtt_handle.on_message = on_message;
  mqtt_handle.client_id = multilocator_id;

  rc = mqtt_init(&mqtt_handle);
  app_assert(rc == MQTT_SUCCESS, "MQTT init failed.\n");

  // Initialize NCP connection.
  sc = ncp_host_init();
  if (sc == SL_STATUS_INVALID_PARAMETER) {
    app_log(USAGE, argv[0]);
    exit(EXIT_FAILURE);
  }
  app_assert_status(sc);
  app_log_info("NCP host initialised." APP_LOG_NEW_LINE);
  app_log_info("Resetting NCP target..." APP_LOG_NEW_LINE);
  // Reset NCP to ensure it gets into a defined state.
  // Once the chip successfully boots, boot event should be received.
  sl_bt_system_reset(sl_bt_system_boot_mode_normal);

  init_connection();
  app_log_info("Press Crtl+C to quit" APP_LOG_NEW_LINE APP_LOG_NEW_LINE);
}

/**************************************************************************//**
 * Application Process Action.
 *****************************************************************************/
void app_process_action(void)
{
  mqtt_status_t rc;
  rc = mqtt_step(&mqtt_handle);
  app_assert(rc == MQTT_SUCCESS, "MQTT step failed.\n");
}

/**************************************************************************//**
 * Application Deinit.
 *****************************************************************************/
void app_deinit(void)
{
  app_log("Shutting down.\n");
  ncp_host_deinit();
  mqtt_deinit(&mqtt_handle);
  if (mqtt_host != NULL) {
    free(mqtt_host);
  }
}

/**************************************************************************//**
 * Configuration file parser.
 *****************************************************************************/
static void parse_config(char *filename)
{
  sl_status_t sc;
  char *buffer;
  aoa_locator_t *loc;

  app_log("start to load the configuration file \n");

  buffer = load_file(filename);
  app_assert(buffer != NULL, "Failed to load file: %s\n", filename);

  sc = aoa_parse_init(buffer);
  app_assert(sc == SL_STATUS_OK,
             "[E: 0x%04x] aoa_parse_init failed\n",
             (int)sc);

  sc = aoa_parse_multilocator(multilocator_id);
  app_assert(sc == SL_STATUS_OK,
             "[E: 0x%04x] aoa_parse_multilocator failed\n",
             (int)sc);

#ifdef AOA_ANGLE
  sc = aoa_parse_azimuth(&aoa_azimuth_min, &aoa_azimuth_max);
  app_assert((sc == SL_STATUS_OK) || (sc == SL_STATUS_NOT_FOUND),
             "[E: 0x%04x] aoa_parse_azimuth failed" APP_LOG_NL,
             (int)sc);
#endif // AOA_ANGLE

  do {
    loc = &locator_list[locator_count];
    sc = aoa_parse_locator(loc->id, &loc->item, &loc->aox_azimuth_mask.aox_azimuth_min_mask, &loc->aox_azimuth_mask.aox_azimuth_max_mask);
    if (sc == SL_STATUS_OK) {
      app_log("Locator added: id: %s, coordinate: %f %f %f, orientation: %f %f %f, azimuth_mask %f %f\n",
              loc->id,
              loc->item.coordinate_x,
              loc->item.coordinate_y,
              loc->item.coordinate_z,
              loc->item.orientation_x_axis_degrees,
              loc->item.orientation_y_axis_degrees,
              loc->item.orientation_z_axis_degrees,
              loc->aox_azimuth_mask.aox_azimuth_min_mask,
              loc->aox_azimuth_mask.aox_azimuth_max_mask);
              
      ++locator_count;
    } else {
      app_assert(sc == SL_STATUS_NOT_FOUND,
                 "[E: 0x%04x] aoa_parse_locator failed\n",
                 (int)sc);
    }
  } while ((locator_count < MAX_NUM_LOCATORS) && (sc == SL_STATUS_OK));

  app_log("Locator count: %d\n", locator_count);

  sc = aoa_parse_deinit();
  app_assert(sc == SL_STATUS_OK,
             "[E: 0x%04x] aoa_parse_deinit failed\n",
             (int)sc);

  free(buffer);
}




/**************************************************************************//**
 * Bluetooth stack event handler.
 * This overrides the dummy weak implementation.
 *
 * @param[in] evt Event coming from the Bluetooth stack.
 *****************************************************************************/
void sl_bt_on_event(sl_bt_msg_t *evt)
{
  sl_status_t sc;
  mqtt_status_t rc;
  bd_addr address;
  uint8_t address_type;

  // Catch boot event...
  if (SL_BT_MSG_ID(evt->header) == sl_bt_evt_system_boot_id) {
    // Print boot message.
    app_log("Bluetooth stack booted: v%d.%d.%d-b%d\n",
            evt->data.evt_system_boot.major,
            evt->data.evt_system_boot.minor,
            evt->data.evt_system_boot.patch,
            evt->data.evt_system_boot.build);

    // Extract unique ID from BT Address.
    sc = sl_bt_system_get_identity_address(&address, &address_type);
    app_assert(sc == SL_STATUS_OK,
               "[E: 0x%04x] Failed to get Bluetooth address\n",
               (int)sc);
    app_log("GateWay: Bluetooth %s address: %02X:%02X:%02X:%02X:%02X:%02X\n",
            address_type ? "static random" : "public device",
            address.addr[5],
            address.addr[4],
            address.addr[3],
            address.addr[2],
            address.addr[1],
            address.addr[0]);

#if 1


    // aoa_address_to_id(address.addr, address_type, locatorxxd_id);

    // // Connect to the MQTT broker
    // mqtt_handle.client_id = locatorxxd_id;
    // mqtt_handle.on_connect = aoa_on_connect;
    // rc = mqtt_init(&mqtt_handle);
    // app_assert(rc == MQTT_SUCCESS, "MQTT init failed.\n");
#endif

#ifdef AOA_ANGLE
    // Don't need to subscribe it no need to modify the CTE parameters.
    // mqtt_handle.on_message = on_message;
    // subscribe_correction();
#endif // AOA_ANGLE
  }
  // ...then call the connection specific event handler.
  app_bt_on_event(evt);
}

#ifdef AOA_ANGLE
/**************************************************************************//**
 * Subscribe for angle feedback messages from the multilocator.
 *****************************************************************************/
static void subscribe_correction(void)
{
  const char topic_template[] = AOA_TOPIC_CORRECTION_PRINT;
  char topic[sizeof(topic_template) + sizeof(aoa_id_t) + 1];
  mqtt_status_t rc;

  snprintf(topic, sizeof(topic), topic_template, locatorxxd_id, "+");

  app_log("Subscribing to topic '%s'.\n", topic);

  rc = mqtt_subscribe(&mqtt_handle, topic);
  app_assert(rc == MQTT_SUCCESS, "Failed to subscribe to topic '%s'.\n", topic);
}

/**************************************************************************//**
 * MQTT message arrived callback.
 *****************************************************************************/
static void on_message(mqtt_handle_t *handle, const char *topic, const char *payload)
{
  int result;
  aoa_id_t loc_id, tag_id;
  aoa_correction_t correction;
  bd_addr tag_addr;
  uint8_t tag_addr_type;
  conn_properties_t *tag = NULL;
  enum sl_rtl_error_code ec;
  sl_status_t sc;

  (void)handle;

#if 0 // For the case of aod_gateway, there is no need to subscribe to AOA_TOPIC_CORRECTION_SCAN topic, 
// and no need to deal with the correction message
  // Parse topic
  result = sscanf(topic, AOA_TOPIC_CORRECTION_SCAN, loc_id, tag_id);
  app_assert(result == 2, "Failed to parse correction topic: %d.\n", result);

  if (aoa_id_compare(loc_id, locator_id) != 0) {
    // Accidentally got a wrong message
    return;
  }
  // Find asset tag in the database
  sc = aoa_id_to_address(tag_id, tag_addr.addr, &tag_addr_type);
  if (SL_STATUS_OK == sc) {
    tag = get_connection_by_address(&tag_addr);
  }
  if (tag != NULL) {
    // Parse payload
    sc = aoa_deserialize_correction((char *)payload, &correction);
    app_assert(sc == SL_STATUS_OK,
               "[E: 0x%04x] aoa_deserialize_correction failed\n",
               (int)sc);

    if (aoa_sequence_compare(tag->sequence, correction.sequence) <= MAX_CORRECTION_DELAY) {
      app_log("Apply correction #%d for asset tag '%s'\n", correction.sequence, tag_id);
      ec = aoa_set_correction(&tag->aoa_state, &correction);
      app_assert(ec == SL_RTL_ERROR_SUCCESS,
                 "[E: %d] Failed to set correction values\n", ec);
    } else {
      app_log("Omit correction #%d for asset tag '%s'\n", correction.sequence, tag_id);
    }
  }

#endif
}
#endif // AOA_ANGLE

/**************************************************************************//**
 * IQ report callback.
 *****************************************************************************/
void app_on_iq_report(conn_properties_t *tag_conn, bd_addr locator_address, uint8_t locator_addr_type, aoa_iq_report_t *iq_report)
{
  aoa_id_t locator_id;
  aoa_id_t tag_id;
  mqtt_status_t rc;
  char *payload;
  sl_status_t sc;

// #ifndef AOA_ANGLE
//   const char topic_template[] = AOA_TOPIC_IQ_REPORT_PRINT;

//   // Compile payload
//   sc = aoa_serialize_iq_report(iq_report, &payload);
// #else

  enum sl_rtl_error_code ec;
  aoa_angle_t angle;
  const char topic_template[] = AOA_TOPIC_ANGLE_PRINT;

  // ec = aoa_calculate(&tag_conn->aoa_state, iq_report, &angle);
  ec = aoa_calculate(get_libitem_by_locator_address(tag_conn, &locator_address), iq_report, &angle);
  // ec = aoa_calculate(get_libitem_by_locator_address(tag_conn, &tag_conn->address), iq_report, &angle);
  if (ec == SL_RTL_ERROR_ESTIMATION_IN_PROGRESS) {
    // No valid angles are available yet.
    return;
  }

  app_assert(ec == SL_RTL_ERROR_SUCCESS,
             "[E: %d] Failed to calculate angle\n", ec);

  // Store the latest sequence number for the tag_conn.
  tag_conn->sequence = iq_report->event_counter;

  // Compile payload
  sc = aoa_serialize_angle(&angle, &payload);

#if 0
  app_log("azimuth: %6.1f  \televation: %6.1f  \trssi: %6.0f  \tch: %2d  \tSequence: %5d  \tDistance: %6.3f  \t",
          angle.azimuth, angle.elevation, iq_report->rssi / 1.0, iq_report->channel, iq_report->event_counter, angle.distance, angle.quality);

  // Check the IQ sample quality result and present a short string according to it
  char *iq_sample_qa_string;
  if (angle.quality == 0) {
    iq_sample_qa_string = "Good                                   ";
  } else if (SL_RTL_AOX_IQ_SAMPLE_QA_IS_SET(angle.quality, SL_RTL_AOX_IQ_SAMPLE_QA_REF_ANT_PHASE_JITTER)
              || SL_RTL_AOX_IQ_SAMPLE_QA_IS_SET(angle.quality, SL_RTL_AOX_IQ_SAMPLE_QA_ANT_X_PHASE_JITTER)) {
    iq_sample_qa_string = "Caution - phase jitter too large       ";
  } else if (SL_RTL_AOX_IQ_SAMPLE_QA_IS_SET(angle.quality, SL_RTL_AOX_IQ_SAMPLE_QA_SNDR)) {
    iq_sample_qa_string = "Caution - reference period SNDR too low";
  } else {
    iq_sample_qa_string = "Caution (other)                        ";
  }
  app_log("IQ sample Quality: %s \r\n", iq_sample_qa_string);
// #endif

#endif // AOA_ANGLE
  app_assert(sc == SL_STATUS_OK,
             "[E: 0x%04x] Failed to serialize the payload.\n",
             (int)sc);

  // Compile topic
  char topic[sizeof(topic_template) + sizeof(aoa_id_t) + sizeof(aoa_id_t)];
  aoa_address_to_id(tag_conn->address.addr, tag_conn->address_type, tag_id);
  aoa_address_to_id(locator_address.addr, locator_addr_type, locator_id);
  snprintf(topic, sizeof(topic), topic_template, tag_id, locator_id);

#if 1
  char *payloadWithRssi = NULL;
  char rssiValue[15];
  // app_log("payload length is %d %s\r\n", strlen(payload), payload);

  sprintf(rssiValue, ",	\"rssi\":	%d", iq_report->rssi);

  // app_log("rssiValus is %s \r\n", rssiValue);

  payloadWithRssi = malloc(strlen(payload) + strlen(rssiValue));
  // app_log("payloadWithRssi length is %d \r\n", strlen(payloadWithRssi));
  if(payloadWithRssi != NULL){
    sprintf(payloadWithRssi, "%.*s %s %s", strlen(payload)-2, payload, rssiValue, "}");
    // app_log("payloadWithRssi %s \r\n", payloadWithRssi);
  }

  publish_angle(topic, payloadWithRssi);
  free(payloadWithRssi);
#else
  publish_angle(topic, payload);
#endif

  // Calculate the tag position information.
  on_message_cal_position(topic, payload);

  // Clean up
  free(payload);
}


#ifdef USE_OLD_ALGORITHM
   // Calculate the position with angle get from multi locators
/**************************************************************************//**
 * Payload message received from the connected tag asset.
 *****************************************************************************/
static void on_message_cal_position(const char *topic, const char *payload)
{
  int result;
  aoa_id_t loc_id, tag_id;
  uint32_t loc_idx, tag_idx;
  aoa_asset_tag_t *tag;
  aoa_angle_t angle;
  enum sl_rtl_error_code ec;
  sl_status_t sc;  

  // app_log("Topic %s payload %s \r\n", topic, payload);

  // Parse topic.
  result = sscanf(topic, AOA_TOPIC_ANGLE_SCAN, tag_id, loc_id);
  app_assert(result == 2, "Failed to parse angle topic: %d.\n", result);

  // Find locator.
  loc_idx = find_locator(loc_id);
  // app_assert(loc_idx != INVALID_IDX, "Failed to find locator %s.\n", loc_id);
  if(loc_idx == INVALID_IDX)
  {
      app_log("Failed to find locator %s.\n", loc_id);
      return;
  }
  
  // Find asset tag.
  tag_idx = find_asset_tag(tag_id);

  if (tag_idx == INVALID_IDX) {
    if (asset_tag_count < MAX_NUM_TAGS) {
      // Add new tag
      sc = init_asset_tag(&asset_tag_list[asset_tag_count], tag_id);
      app_assert(sc == SL_RTL_ERROR_SUCCESS,
                 "[E: 0x%04x] Failed to init asset tag %s.\n", sc, tag_id);
      app_log("New tag added (%d): %s\n", asset_tag_count, tag_id);
      tag_idx = asset_tag_count++;
    } else {
      app_log("Warning! Maximum number of asset tags reached: %d\n", asset_tag_count);
      // No further procesing possible.
      return;
    }
  }

  // Create shortcut.
  tag = &asset_tag_list[tag_idx];

  // Parse payload.

  // Parse payload and get the angle calculated with the given locator.
  // 每一个tag可以对多个locator的beacon进行IQ sample，并计算得出angle值。
  // 因此需要收集所有locator对应的angle数据，然后计算得出tag的position信息。
  // aod_gateway 可同时收集多个tag的数据，每一个tag又对应多个locator
  aoa_deserialize_angle((char *)payload, &tag->angle[loc_idx]);
  // aoa_string_to_angle((char *)payload, &tag->angle[loc_idx]);
  tag->ready[loc_idx] = true;

  // Run estimation and publish results.
  if (is_ready(tag)) {
    sc = run_estimation(tag);
    app_assert(sc == SL_RTL_ERROR_SUCCESS,
               "[E: 0x%04x] Position estimation failed for %s.\n", sc, tag->id);

    // if(tag->position.z != 0)
    {
      app_log("tag id %s\n", tag->id);
      app_log("x %f, y %f, z %f \r\n", tag->position.x, tag->position.y, tag->position.z );
    }

    enum sl_rtl_loc_estimation_mode mode;
    mode = ESTIMATION_MODE;
    if((mode == SL_RTL_LOC_ESTIMATION_MODE_TWO_DIM_HIGH_ACCURACY) || (mode == SL_RTL_LOC_ESTIMATION_MODE_TWO_DIM_FAST_RESPONSE)){
      if(tag->position.z != 0){
        app_log("Set the Z-axis as a constant value for 2D estimation mode\n");
        tag->position.z = 0;
      }
    }


    publish_position(tag);
    app_log("\n\n\n");

    // Check if some of the locators require correction.
    if (enable_feedback && sl_rtl_loc_get_number_disabled(&tag->loc) > 0) {
      aoa_correction_t correction;
      app_log("some of the locator require correction... ->->->-> \r\n");
      for (uint32_t l = 0; l < locator_count; l++) {
        sc = sl_rtl_loc_get_expected_direction(&tag->loc,
                                                tag->loc_id[l],
                                                &correction.direction.azimuth,
                                                &correction.direction.elevation,
                                                &correction.direction.distance);
        if (sc == SL_RTL_ERROR_INCORRECT_MEASUREMENT) {
          sl_rtl_loc_get_expected_deviation(&tag->loc,
                                            tag->loc_id[l],
                                            &correction.deviation.azimuth,
                                            &correction.deviation.elevation,
                                            &correction.deviation.distance);
          correction.sequence = tag->position.sequence;
          set_correction(tag, l, &correction);
        }
      }
    }

  }
}


/**************************************************************************//**
 * Check if all data are ready for a tag to run estimation.
 *****************************************************************************/
static bool is_ready(aoa_asset_tag_t *tag)
{
  for (uint32_t i = 0; i < locator_count; i++) {
    if (tag->ready[i] == false) {
      return false;
    }
  }
  return true;
}




/**************************************************************************//**
 * Run position estimation algorithm for a given asset tag.
 *****************************************************************************/
static enum sl_rtl_error_code run_estimation(aoa_asset_tag_t *tag)
{
  enum sl_rtl_error_code sc;

  // Feed measurement values into RTL lib.
  for (uint32_t i = 0; i < locator_count; i++) {
    sc = sl_rtl_loc_set_locator_measurement(&tag->loc,
                                            tag->loc_id[i],
                                            SL_RTL_LOC_LOCATOR_MEASUREMENT_AZIMUTH,
                                            tag->angle[i].azimuth);
    CHECK_ERROR(sc);

    sc = sl_rtl_loc_set_locator_measurement(&tag->loc,
                                            tag->loc_id[i],
                                            SL_RTL_LOC_LOCATOR_MEASUREMENT_ELEVATION,
                                            tag->angle[i].elevation);
    CHECK_ERROR(sc);

    // Feeding RSSI distance measurement to the RTL library improves location
    // accuracy when the measured distance is reasonably correct.
    // If the received signal strength of the incoming signal is altered for any
    // other reason than the distance between the TX and RX itself, it will lead
    // to incorrect measurement and it will lead to incorrect position estimates.
    // For this reason the RSSI distance usage is disabled by default in the
    // multilocator case.
    // Single locator mode however always requires the distance measurement in
    // addition to the angle, please note the if-condition below.
    // In case the distance estimation should be used in the  multilocator case,
    // you can enable it by commenting out the condition.
    if (locator_count == 1) {
      sc = sl_rtl_loc_set_locator_measurement(&tag->loc,
                                              tag->loc_id[i],
                                              SL_RTL_LOC_LOCATOR_MEASUREMENT_DISTANCE,
                                              tag->angle[i].distance);
      CHECK_ERROR(sc);
    }
    tag->ready[i] = false;
  }

  // Process new measurements, time step given in seconds.
  sc = sl_rtl_loc_process(&tag->loc, ESTIMATION_INTERVAL_SEC);
  CHECK_ERROR(sc);

  // Get results from the estimator.
  sc = sl_rtl_loc_get_result(&tag->loc, SL_RTL_LOC_RESULT_POSITION_X, &tag->position.x);
  CHECK_ERROR(sc);
  sc = sl_rtl_loc_get_result(&tag->loc, SL_RTL_LOC_RESULT_POSITION_Y, &tag->position.y);
  CHECK_ERROR(sc);
  sc = sl_rtl_loc_get_result(&tag->loc, SL_RTL_LOC_RESULT_POSITION_Z, &tag->position.z);
  CHECK_ERROR(sc);

  // Apply filter on the result.
  sc = sl_rtl_util_filter(&tag->filter[AXIS_X], tag->position.x, &tag->position.x);
  CHECK_ERROR(sc);
  sc = sl_rtl_util_filter(&tag->filter[AXIS_Y], tag->position.y, &tag->position.y);
  CHECK_ERROR(sc);
  sc = sl_rtl_util_filter(&tag->filter[AXIS_Z], tag->position.z, &tag->position.z);
  CHECK_ERROR(sc);

  tag->position.sequence++;

  // Clear measurements.
  sc = sl_rtl_loc_clear_measurements(&tag->loc);
  CHECK_ERROR(sc);

  return SL_RTL_ERROR_SUCCESS;
}


/**************************************************************************//**
 * Publish angle of a given tag and locator.
 *****************************************************************************/
static void publish_angle(const char *topic, const char *payload)
{
  mqtt_status_t rc;

  // Send message
  rc = mqtt_publish(&mqtt_handle, topic, payload);
  app_assert(rc == MQTT_SUCCESS, "Failed to publish to topic '%s'.\n", topic);
}

/**************************************************************************//**
 * Publish position of a given tag.
 *****************************************************************************/
static void publish_position(aoa_asset_tag_t *tag)
{
  sl_status_t sc;
  mqtt_status_t rc;
  char *payload;
  const char topic_template[] = AOA_TOPIC_POSITION_PRINT;
  char topic[sizeof(topic_template) + sizeof(aoa_id_t) + sizeof(aoa_id_t)];

  // Compile topic.
  snprintf(topic, sizeof(topic), topic_template, multilocator_id, tag->id);

  // Compile payload.
  sc = aoa_serialize_position(&tag->position, &payload);
  app_assert(sc == SL_STATUS_OK,
             "[E: 0x%04x] aoa_serialize_position failed.\n",
             (int)sc);  
  
  printf("position of the tag: %s\r\n", payload);

#if 1
  rc = mqtt_publish(&mqtt_handle, topic, payload);
  app_assert(rc == MQTT_SUCCESS, "Failed to publish to topic '%s'.\n", topic);
#endif

  // Clean up.
  free(payload);
}


/**************************************************************************//**
 * Initialise a new asset tag.
 *****************************************************************************/
static enum sl_rtl_error_code init_asset_tag(aoa_asset_tag_t *tag, aoa_id_t id)
{
  enum sl_rtl_error_code sc;
  enum sl_rtl_loc_estimation_mode mode;

  aoa_id_copy(tag->id, id);

  // Initialize RTL library
  sc = sl_rtl_loc_init(&tag->loc);
  CHECK_ERROR(sc);

  // Select estimation mode.
  sc = sl_rtl_loc_set_mode(&tag->loc, ESTIMATION_MODE);
  CHECK_ERROR(sc);

  mode = ESTIMATION_MODE;
  if((mode == SL_RTL_LOC_ESTIMATION_MODE_TWO_DIM_HIGH_ACCURACY) || (mode == SL_RTL_LOC_ESTIMATION_MODE_TWO_DIM_FAST_RESPONSE))
  {
    sc = sl_rtl_loc_set_target_parameter(&tag->loc, SL_RTL_LOC_TARGET_PARAMETER_TARGET_HEIGHT, 0.6);
    CHECK_ERROR(sc);
  }

  // Provide locator configurations to the position estimator.
  for (uint32_t i = 0; i < locator_count; i++) {
    sc = sl_rtl_loc_add_locator(&tag->loc, &locator_list[i].item, &tag->loc_id[i]);
    CHECK_ERROR(sc);

// Each tag has a conn_properties entry which contain the aoa_state
// #ifdef AOA_ANGLE
//     sc = aoa_init(&tag->aoa_state[i]);
//     CHECK_ERROR(sc);
// #endif // AOA_ANGLE

    tag->ready[i] = false;
  }

  // Create position estimator.
  sc = sl_rtl_loc_create_position_estimator(&tag->loc);
  CHECK_ERROR(sc);

  if (enable_feedback) {
    // Turn on the bad angle detection mechanism.
    sc = sl_rtl_loc_set_measurement_validation(&tag->loc, VALIDATION_MODE);
    CHECK_ERROR(sc);
  }

  // Initialize util functions.
  for (enum axis_list i = 0; i < AXIS_COUNT; i++) {
    sc = sl_rtl_util_init(&tag->filter[i]);
    CHECK_ERROR(sc);
    // Set position filtering parameter for every axis.
    sc = sl_rtl_util_set_parameter(&tag->filter[i],
                                   SL_RTL_UTIL_PARAMETER_AMOUNT_OF_FILTERING,
                                   FILTERING_AMOUNT);
    CHECK_ERROR(sc);
  }

  return SL_RTL_ERROR_SUCCESS;
}

/**************************************************************************//**
 * Find asset tag in the local list based on its ID.
 *****************************************************************************/
static uint32_t find_asset_tag(aoa_id_t id)
{
  uint32_t retval = INVALID_IDX;

  for (uint32_t i = 0; (i < asset_tag_count) && (retval == INVALID_IDX); i++) {
    if (aoa_id_compare(asset_tag_list[i].id, id) == 0) {
      retval = i;
    }
  }
  return retval;
}

/**************************************************************************//**
 * Find locator in the local list based on its ID.
 *****************************************************************************/
static uint32_t find_locator(aoa_id_t id)
{
  uint32_t retval = INVALID_IDX;

  for (uint32_t i = 0; (i < locator_count) && (retval == INVALID_IDX); i++) {
    if (aoa_id_compare(locator_list[i].id, id) == 0) {
      retval = i;
    }
  }
  return retval;
}


/**************************************************************************//**
 * Set angle correction feedback.
 *****************************************************************************/
// #ifdef AOA_ANGLE
# if 1
static void set_correction(aoa_asset_tag_t *tag, uint32_t loc_idx, aoa_correction_t *correction)
{
  bd_addr tag_addr;
  uint8_t tag_addr_type;
  bd_addr locator_addr;
  uint8_t locator_addr_type;
  conn_properties_t *tag_conn = NULL;
  enum sl_rtl_error_code ec;
  sl_status_t sc;

  // The first angle in the correlated angle list is the most recent one.
  // if (aoa_sequence_compare(tag->correlated_angles[0].sequence, correction->sequence) <= MAX_CORRECTION_DELAY) 
  if(1){
    app_log("Apply correction #%d for asset tag '%s', locator '%s'\n", correction->sequence, tag->id, locator_list[loc_idx].id);

    // Find asset tag in the database
    sc = aoa_id_to_address(tag->id, tag_addr.addr, &tag_addr_type);
    if (SL_STATUS_OK == sc) {
      tag_conn = get_connection_by_address(&tag_addr);
    }

    if(tag_conn != NULL)
    {
      // 参数所传递的 loc_idx 是由 tag->loc_id[l] 传递而来，tag->loc_id[] 与 locator_list[] share 同一个index, 请参考init_asset_tag()
      sc = aoa_id_to_address(locator_list[loc_idx].id, locator_addr.addr, &locator_addr_type);
      if (SL_STATUS_OK == sc) {
        ec = aoa_set_correction(get_libitem_by_locator_address(tag_conn, &locator_addr), correction);
        app_assert(ec == SL_RTL_ERROR_SUCCESS,
          "[E: %d] Failed to set correction values\n", ec);
      }
    }
  } else {
    app_log("Omit correction #%d for asset tag '%s'\n", correction->sequence, tag->id);
  }
}
#else
static void set_correction(aoa_asset_tag_t *tag, uint32_t loc_idx, aoa_correction_t *correction)
{
  sl_status_t sc;
  mqtt_status_t rc;
  char *payload;
  const char topic_template[] = AOA_TOPIC_CORRECTION_PRINT;
  char topic[sizeof(topic_template) + sizeof(aoa_id_t) + sizeof(aoa_id_t)];

  // Compile topic
  snprintf(topic, sizeof(topic), topic_template, locator_list[loc_idx].id, tag->id);

  // Compile payload
  sc = aoa_serialize_correction(correction, &payload);
  app_assert(sc == SL_STATUS_OK,
             "[E: 0x%04x] aoa_serialize_correction failed.\n",
             (int)sc);

  rc = mqtt_publish(&mqtt_handle, topic, payload);
  app_assert(rc == MQTT_SUCCESS, "Failed to publish to topic '%s'.\n", topic);

  // Clean up
  free(payload);
}
#endif // AOA_ANGLE



#else

/**************************************************************************//**
 * MQTT message arrived callback.
 *****************************************************************************/
static void on_message_cal_position(const char *topic, const char *payload)
{
  int result;
  aoa_id_t loc_id, tag_id;
  uint32_t loc_idx, tag_idx;
  aoa_asset_tag_t *tag;
  aoa_angle_t angle;
  enum sl_rtl_error_code ec;
  sl_status_t sc;

  app_log("->->-> topic %s payload %s \r\n", topic, payload);

  // Parse topic.
  result = sscanf(topic, AOA_TOPIC_ANGLE_SCAN, tag_id, loc_id);
  // result = sscanf(topic, SUBSCRIBE_TOPIC_SCAN, tag_id, loc_id);
  app_assert(result == 2, "Failed to parse topic: %d.\n", result);

  // Find locator.
  loc_idx = find_locator(loc_id);
  app_assert(loc_idx != INVALID_IDX, "Failed to find locator %s.\n", loc_id);

  // Find asset tag.
  tag_idx = find_asset_tag(tag_id);

  if (tag_idx == INVALID_IDX) {
    if (asset_tag_count < MAX_NUM_TAGS) {
      // Add new tag
      ec = init_asset_tag(&asset_tag_list[asset_tag_count], tag_id);
      app_assert(ec == SL_RTL_ERROR_SUCCESS,
                 "[E: 0x%04x] Failed to init asset tag %s.\n", ec, tag_id);
      app_log("New tag added (%d): %s\n", asset_tag_count, tag_id);
      tag_idx = asset_tag_count++;
    } else {
      app_log("Warning! Maximum number of asset tags reached: %d\n", asset_tag_count);
      // No further procesing possible.
      return;
    }
  }

  // Create shortcut.
  tag = &asset_tag_list[tag_idx];

// #ifdef AOA_ANGLE
//   aoa_iq_report_t iq_report;
//   int8_t samples[256];
//   iq_report.samples = samples;

//   // Parse payload.
//   sc = aoa_deserialize_iq_report((char *)payload, &iq_report);

//   // Convert IQ report to angle.
//   ec = aoa_calculate(&tag->aoa_state[loc_idx], &iq_report, &angle);
//   if (ec == SL_RTL_ERROR_ESTIMATION_IN_PROGRESS) {
//     // No valid angles are available yet.
//     return;
//   }
//   app_assert(ec == SL_RTL_ERROR_SUCCESS,
//              "[E: %d] Failed to calculate angle\n", ec);
// #else
//   // Parse payload.
//   sc = aoa_deserialize_angle((char *)payload, &angle);
// #endif // AOA_ANGLE
//   app_assert(sc == SL_STATUS_OK,
//              "[E: 0x%04x] Failed to deserialize the payload.\n",
//              (int)sc);

  sc = aoa_deserialize_angle((char *)payload, &angle);
  app_assert(sc == SL_STATUS_OK,
             "[E: 0x%04x] Failed to deserialize the payload.\n",
             (int)sc);
  add_angle_data_to_tag(tag, loc_idx, &angle);
}

/**************************************************************************//**
 * Subscribe for angle or IQ report data published by a given locator.
 *****************************************************************************/
// static void subscribe_topic(aoa_locator_t *loc)
// {
//   const char topic_template[] = SUBSCRIBE_TOPIC_PRINT;
//   char topic[sizeof(topic_template) + sizeof(aoa_id_t) + 1];
//   mqtt_status_t rc;

//   snprintf(topic, sizeof(topic), topic_template, loc->id, "+");

//   app_log("Subscribing to topic '%s'.\n", topic);

//   rc = mqtt_subscribe(&mqtt_handle, topic);
//   app_assert(rc == MQTT_SUCCESS, "Failed to subscribe to topic '%s'.\n", topic);
// }

/**************************************************************************//**
 * Publish position of a given tag.
 *****************************************************************************/
static void publish_position(aoa_asset_tag_t *tag)
{
  sl_status_t sc;
  mqtt_status_t rc;
  char *payload;
  const char topic_template[] = AOA_TOPIC_POSITION_PRINT;
  char topic[sizeof(topic_template) + sizeof(aoa_id_t) + sizeof(aoa_id_t)];

  // Compile topic.
  snprintf(topic, sizeof(topic), topic_template, multilocator_id, tag->id);

  // Compile payload.
  sc = aoa_serialize_position(&tag->position, &payload);
  app_assert(sc == SL_STATUS_OK,
             "[E: 0x%04x] aoa_serialize_position failed.\n",
             (int)sc);

  app_log("Tag position %s \r\n", payload);

  // rc = mqtt_publish(&mqtt_handle, topic, payload);
  // app_assert(rc == MQTT_SUCCESS, "Failed to publish to topic '%s'.\n", topic);

  // Clean up.
  free(payload);
}

/**************************************************************************//**
 * Set angle correction feedback.
 *****************************************************************************/
#ifdef AOA_ANGLE
static void set_correction(aoa_asset_tag_t *tag, uint32_t loc_idx, aoa_correction_t *correction)
{
  enum sl_rtl_error_code ec;
  // The first angle in the correlated angle list is the most recent one.
  if (aoa_sequence_compare(tag->correlated_angles[0].sequence, correction->sequence) <= MAX_CORRECTION_DELAY) {
    app_log("Apply correction #%d for asset tag '%s', locator '%s'\n", correction->sequence, tag->id, locator_list[loc_idx].id);
    ec = aoa_set_correction(&tag->aoa_state[loc_idx], correction);
    app_assert(ec == SL_RTL_ERROR_SUCCESS,
               "[E: %d] Failed to set correction values\n", ec);
  } else {
    app_log("Omit correction #%d for asset tag '%s'\n", correction->sequence, tag->id);
  }
}
#else
static void set_correction(aoa_asset_tag_t *tag, uint32_t loc_idx, aoa_correction_t *correction)
{
  sl_status_t sc;
  mqtt_status_t rc;
  char *payload;
  const char topic_template[] = AOA_TOPIC_CORRECTION_PRINT;
  char topic[sizeof(topic_template) + sizeof(aoa_id_t) + sizeof(aoa_id_t)];

  // Compile topic
  snprintf(topic, sizeof(topic), topic_template, locator_list[loc_idx].id, tag->id);

  // Compile payload
  sc = aoa_serialize_correction(correction, &payload);
  app_assert(sc == SL_STATUS_OK,
             "[E: 0x%04x] aoa_serialize_correction failed.\n",
             (int)sc);

  rc = mqtt_publish(&mqtt_handle, topic, payload);
  app_assert(rc == MQTT_SUCCESS, "Failed to publish to topic '%s'.\n", topic);

  // Clean up
  free(payload);
}
#endif // AOA_ANGLE

/**************************************************************************//**
 * Run position estimation algorithm for a given asset tag.
 *****************************************************************************/
static enum sl_rtl_error_code run_estimation(aoa_asset_tag_t *tag, uint32_t slot)
{
  enum sl_rtl_error_code sc;
  float time_step = ESTIMATION_INTERVAL_SEC;
  int32_t seq_diff;

  // Feed measurement values into RTL lib.
  for (uint32_t i = 0; i < locator_count; i++) {
    if (tag->correlated_angles[slot].has_angle[i]) {
      sc = sl_rtl_loc_set_locator_measurement(&tag->loc,
                                              tag->loc_id[i],
                                              SL_RTL_LOC_LOCATOR_MEASUREMENT_AZIMUTH,
                                              tag->correlated_angles[slot].angles[i].azimuth);
      CHECK_ERROR(sc);

      sc = sl_rtl_loc_set_locator_measurement(&tag->loc,
                                              tag->loc_id[i],
                                              SL_RTL_LOC_LOCATOR_MEASUREMENT_ELEVATION,
                                              tag->correlated_angles[slot].angles[i].elevation);
      CHECK_ERROR(sc);

      // Feeding RSSI distance measurement to the RTL library improves location
      // accuracy when the measured distance is reasonably correct.
      // If the received signal strength of the incoming signal is altered for any
      // other reason than the distance between the TX and RX itself, it will lead
      // to incorrect measurement and it will lead to incorrect position estimates.
      // For this reason the RSSI distance usage is disabled by default in the
      // multilocator case.
      // Single locator mode however always requires the distance measurement in
      // addition to the angle, please note the if-condition below.
      // In case the distance estimation should be used in the  multilocator case,
      // you can enable it by commenting out the condition.
      if (locator_count == 1) {
        sc = sl_rtl_loc_set_locator_measurement(&tag->loc,
                                                tag->loc_id[i],
                                                SL_RTL_LOC_LOCATOR_MEASUREMENT_DISTANCE,
                                                tag->correlated_angles[slot].angles[i].distance);
        CHECK_ERROR(sc);
      }
    }
  }

  // Estimate the time step based on the sequence number.
  seq_diff = aoa_sequence_compare(tag->correlated_angles[slot].sequence,
                                  tag->position.sequence);
  if (seq_diff <= MAX_SEQUENCE_DIFF) {
    time_step *= (float)seq_diff;
  }

  // Process new measurements, time step given in seconds.
  sc = sl_rtl_loc_process(&tag->loc, time_step);
  tag->position.sequence = tag->correlated_angles[slot].sequence;

  CHECK_ERROR(sc);

  // Get results from the estimator.
  sc = sl_rtl_loc_get_result(&tag->loc, SL_RTL_LOC_RESULT_POSITION_X, &tag->position.x);
  CHECK_ERROR(sc);
  sc = sl_rtl_loc_get_result(&tag->loc, SL_RTL_LOC_RESULT_POSITION_Y, &tag->position.y);
  CHECK_ERROR(sc);
  sc = sl_rtl_loc_get_result(&tag->loc, SL_RTL_LOC_RESULT_POSITION_Z, &tag->position.z);
  CHECK_ERROR(sc);

  // Apply filter on the result.
  sc = sl_rtl_util_filter(&tag->filter[AXIS_X], tag->position.x, &tag->position.x);
  CHECK_ERROR(sc);
  sc = sl_rtl_util_filter(&tag->filter[AXIS_Y], tag->position.y, &tag->position.y);
  CHECK_ERROR(sc);
  sc = sl_rtl_util_filter(&tag->filter[AXIS_Z], tag->position.z, &tag->position.z);
  CHECK_ERROR(sc);

  // Clear measurements.
  sc = sl_rtl_loc_clear_measurements(&tag->loc);
  CHECK_ERROR(sc);

  return SL_RTL_ERROR_SUCCESS;
}

/**************************************************************************//**
 * Initialise a new asset tag.
 *****************************************************************************/
static enum sl_rtl_error_code init_asset_tag(aoa_asset_tag_t *tag, aoa_id_t id)
{
  enum sl_rtl_error_code sc;

  aoa_id_copy(tag->id, id);
  tag->position.sequence = -1;  // Invalid sequence

  // Initialize RTL library
  sc = sl_rtl_loc_init(&tag->loc);
  CHECK_ERROR(sc);

  // Select estimation mode.
  sc = sl_rtl_loc_set_mode(&tag->loc, ESTIMATION_MODE);
  CHECK_ERROR(sc);

  // Provide locator configurations to the position estimator.
  for (uint32_t i = 0; i < locator_count; i++) {
    sc = sl_rtl_loc_add_locator(&tag->loc, &locator_list[i].item, &tag->loc_id[i]);
    CHECK_ERROR(sc);
#ifdef AOA_ANGLE
    sc = aoa_init(&tag->aoa_state[i]);
    CHECK_ERROR(sc);
#endif // AOA_ANGLE
  }
  for (uint32_t i = 0; i < MAX_NUM_SEQUENCE_IDS; i++) {
    init_correlated_angle_data(&tag->correlated_angles[i]);
  }

  // Create position estimator.
  sc = sl_rtl_loc_create_position_estimator(&tag->loc);
  CHECK_ERROR(sc);

  if (enable_feedback) {
    // Turn on the bad angle detection mechanism.
    sc = sl_rtl_loc_set_measurement_validation(&tag->loc, VALIDATION_MODE);
    CHECK_ERROR(sc);
  }

  // Initialize util functions.
  for (enum axis_list i = 0; i < AXIS_COUNT; i++) {
    sc = sl_rtl_util_init(&tag->filter[i]);
    CHECK_ERROR(sc);
    // Set position filtering parameter for every axis.
    sc = sl_rtl_util_set_parameter(&tag->filter[i],
                                   SL_RTL_UTIL_PARAMETER_AMOUNT_OF_FILTERING,
                                   FILTERING_AMOUNT);
    CHECK_ERROR(sc);
  }

  return SL_RTL_ERROR_SUCCESS;
}

/**************************************************************************//**
 * Find asset tag in the local list based on its ID.
 *****************************************************************************/
static uint32_t find_asset_tag(aoa_id_t id)
{
  uint32_t retval = INVALID_IDX;

  for (uint32_t i = 0; (i < asset_tag_count) && (retval == INVALID_IDX); i++) {
    if (aoa_id_compare(asset_tag_list[i].id, id) == 0) {
      retval = i;
    }
  }
  return retval;
}

/**************************************************************************//**
 * Find locator in the local list based on its ID.
 *****************************************************************************/
static uint32_t find_locator(aoa_id_t id)
{
  uint32_t retval = INVALID_IDX;

  for (uint32_t i = 0; (i < locator_count) && (retval == INVALID_IDX); i++) {
    if (aoa_id_compare(locator_list[i].id, id) == 0) {
      retval = i;
    }
  }
  return retval;
}

/**************************************************************************//**
 * Initialize expected angle counts.
 *
 * The expected number of angles depends on the slot index. A slot with smaller
 * index (i.e. with more recent sequence number) expects more angles, while a
 * slot with higher index (i.e. with older sequence number) requires less
 * angles.
 * This function implements a linear connection, thus the first slot expects
 * an angle from all locators, while the last slot needs only 2 locators.
 *****************************************************************************/
static void init_expected_angle_counts(void)
{
  uint32_t coeff = (locator_count < 2) ? 0 : (locator_count - 2);
  for (int i = 0; i < MAX_NUM_SEQUENCE_IDS; i++) {
    expected_angles_count[i] = locator_count - ROUND_DIV(i * coeff, MAX_NUM_SEQUENCE_IDS - 1);
  }
}

/**************************************************************************//**
 * Initialize angle data in a slot.
 *****************************************************************************/
static void init_correlated_angle_data(aoa_correlated_angles_t* angle)
{
  angle->num_angles = 0;
  angle->sequence = -1;
  memset(angle->has_angle, 0, MAX_NUM_LOCATORS);
}

/**************************************************************************//**
 * Add angle data to asset tag.
 *****************************************************************************/
static void add_angle_data_to_tag(aoa_asset_tag_t* tag, uint32_t loc_idx, aoa_angle_t* angle)
{
  // Drop stored data that are considered too old.
  for (int i = 0; i < MAX_NUM_SEQUENCE_IDS; i++) {
    if (aoa_sequence_compare(tag->correlated_angles[i].sequence, angle->sequence) > MAX_SEQUENCE_DIFF) {
      for (int k = i; k < MAX_NUM_SEQUENCE_IDS; k++) {
        init_correlated_angle_data(&tag->correlated_angles[k]);
      }
      break;
    }
  }
  // Find the correct slot.
  int32_t angle_slot = find_angle_slot(tag->correlated_angles, angle->sequence);
  // Update with / insert new data
  update_slots(tag, angle, angle_slot, loc_idx);
  // Push if some of the slots have completed
  push_completed_angle_data(tag, angle_slot);
}

/**************************************************************************//**
 * Find angle slot.
 *****************************************************************************/
static int32_t find_angle_slot(aoa_correlated_angles_t* slots, int32_t sequence)
{
  for (uint32_t i = 0; i < MAX_NUM_SEQUENCE_IDS; i++) {
    if (sequence == slots[i].sequence) {
      return i;
    }
  }
  return 0;
}

/**************************************************************************//**
 * Update slots.
 *****************************************************************************/
static void update_slots(aoa_asset_tag_t* tag, aoa_angle_t* angle, int32_t slot, uint32_t loc_idx)
{
  if (slot >= 0) {
    // If the selected slot has not matched with the angle then insert it.
    if (tag->correlated_angles[slot].sequence != angle->sequence) {
      for (int i = MAX_NUM_SEQUENCE_IDS - 1; i > slot; i--) {
        tag->correlated_angles[i] = tag->correlated_angles[i - 1];
      }
      init_correlated_angle_data(&tag->correlated_angles[slot]);
      tag->correlated_angles[slot].sequence = angle->sequence;
    }
    tag->correlated_angles[slot].angles[loc_idx] = *angle;
    tag->correlated_angles[slot].has_angle[loc_idx] = true;
    tag->correlated_angles[slot].num_angles++;
  }
}

/**************************************************************************//**
 * Push completed angle data to the estimator and publish to MQTT.
 *****************************************************************************/
static void push_completed_angle_data(aoa_asset_tag_t* tag, int32_t check_idx_from)
{
  int32_t last_updated_index = MAX_NUM_SEQUENCE_IDS;
  // Check start from the oldest slots to keep in order and complete as many
  // slots as possible.
  if (check_idx_from >= 0) {
    for (int i = MAX_NUM_SEQUENCE_IDS - 1; i >= check_idx_from; i--) {
      if (tag->correlated_angles[i].num_angles == expected_angles_count[i]) {
        enum sl_rtl_error_code sc = run_estimation(tag, i);
        app_assert(sc == SL_RTL_ERROR_SUCCESS,
                   "[E: 0x%04x] Position estimation failed for %s.\n", sc, tag->id);
        publish_position(tag);
        last_updated_index = i;

        // Check if some of the locators require correction.
        if (enable_feedback && sl_rtl_loc_get_number_disabled(&tag->loc) > 0) {
          aoa_correction_t correction;

          for (uint32_t l = 0; l < locator_count; l++) {
            if (tag->correlated_angles[i].has_angle[l]) {
              sc = sl_rtl_loc_get_expected_direction(&tag->loc,
                                                     tag->loc_id[l],
                                                     &correction.direction.azimuth,
                                                     &correction.direction.elevation,
                                                     &correction.direction.distance);
              if (sc == SL_RTL_ERROR_INCORRECT_MEASUREMENT) {
                sl_rtl_loc_get_expected_deviation(&tag->loc,
                                                  tag->loc_id[l],
                                                  &correction.deviation.azimuth,
                                                  &correction.deviation.elevation,
                                                  &correction.deviation.distance);
                correction.sequence = tag->position.sequence;
                set_correction(tag, l, &correction);
              }
            }
          }
        }
      }
    }
    for (; last_updated_index < MAX_NUM_SEQUENCE_IDS; last_updated_index++) {
      init_correlated_angle_data(&tag->correlated_angles[last_updated_index]);
    }
  }
}



#endif