# -*- coding: utf-8 -*-


import random
from threading import currentThread
import time
import csv
from enum import IntEnum
import re

import threading
from threading import Timer

import os
import pandas as pd
import openpyxl
from pandas.core.frame import DataFrame

class messageDataType(IntEnum):
    POSITION_DATA = 0     # Public address
    ANGLE_DATA = 1    # Random address

# get the current time
str_now_day = time.strftime("%Y-%m-%d", time.localtime(time.time())).replace('-', '')

class dataStore(object):
    def __init__(self):
        self.tagList = []
        self.dfDict = dict()
        print("initial datastore class ... ")

        # Thread lock, otherwise, write the excel in timer handle might conflict with the main thread.
        self.lock = threading.RLock()

        self.eventTimer = Timer(360, self.event_timer_handle)
        self.eventTimer.start()
        print('Timers are started')

    def event_timer_handle(self, *args, **kargs):
        print('Timer trigger ......... ')
        # self.eventTimer = Timer(20, self.event_timer_handle)
        # self.eventTimer.start()
        
        self.lock.acquire(False)
        # print(self.dfDict)
        for key, value in self.dfDict.items():
            m = re.match(r"(?P<file_name>.+).xlsx(?P<sheet_name>.+)", key)
            if (m is not None) and len(value) > 0:
                filename = m.group("file_name")
                filename = filename+'.xlsx'
                sheet_name = m.group("sheet_name")

                writer = pd.ExcelWriter(filename, engine='openpyxl', mode='a')

                # try to open an existing workbook
                writer.book = openpyxl.load_workbook(filename)
                
                startrow = None
                # get the last row in the existing Excel sheet
                # if it was not specified explicitly
                if startrow is None and sheet_name in writer.book.sheetnames:
                    startrow = writer.book[sheet_name].max_row
                    print('startrow is: ')
                    print(startrow)

                # The default header parameter is None, so it will not write the header
                # In the case of first write, remove the header parameter, it will store the header information then.
                # print("+++++++++++++++++++++++++------------------------------------------------------")
                print(' Write entries to file&sheet %s_%s periodically' % (filename, sheet_name))
                # print(writer.book.sheetnames)

                if sheet_name not in writer.book.sheetnames:
                    print('sheet_name: %s not in the excel' % (sheet_name))
                    continue
                    # raise AssertionError("sheet is not exist in the excel file")

                # copy existing sheets
                writer.sheets = {ws.title:ws for ws in writer.book.worksheets}

                if startrow is None:
                    startrow = 0

                dfName = filename+sheet_name
                self.dfDict[dfName].to_excel(writer, sheet_name=sheet_name, startrow=startrow, header=None, index=False)
                # save the workbook
                writer.save()
                writer.close()

                # Clear the dataframe after finishing the excel writing
                df_dummy = pd.DataFrame()
                self.dfDict[dfName] = df_dummy[0:0]
                print('periodically write done --->>> \n\n')
        
        self.lock.release()
            
    # 存csv
    def save_item_in_csv(self, item, dataType=0):
        # print('save item in xlsx...')
        # print(item)
        
        if(dataType == messageDataType.POSITION_DATA):
            fileName = ''
            entryPosition = dict()
            if item["tag_id"] not in self.tagList:
                print('tag is not in the tagList')
                self.tagList.append(item["tag_id"])
                
            # Generate the csv file name
            fileName = "{}.xlsx".format(item["tag_id"])
            str_now_time = time.strftime("%H-%M-%S", time.localtime(time.time()))
            # Generate the entry and append to excel file
            entryPosition["x"] = [item["x"]]
            entryPosition["y"] = [item["y"]]
            entryPosition["z"] = [item["z"]]
            entryPosition["sequence"] = [item["sequence"]]
            entryPosition["timeHMS"] = [str_now_time]

            # print("entryPosition: ")
            # print(entryPosition)

            # write = pd.ExcelWriter(fileName)
            # df = pd.DataFrame({"x":[item["x"]], "y":[item["y"]], "z":[item["z"]], "sequence":[item["sequence"]]})
            # df = pd.DataFrame.from_dict(entryPosition)
            self.append_df_to_excel(fileName, entryPosition, header=None, sheet_name='position', index=False)

                # with pd.ExcelWriter(fileName, mode="w", engine="openpyxl") as writer:
                #     df.to_excel(writer, index=False, sheet_name='position')
                # df.to_excel(writer, 'sheet1')
                
                # writer.save()

                # with open(fileName, "a", encoding="utf-8-sig") as fd:
                #     writer = csv.DictWriter(fd, fieldnames=entryPosition.keys())
                #     writer.writeheader()
                #     writer.writerow(entryPosition)
            # else:
            #     fileName = "{}.xlsx".format(item["tag_id"])
            #     entryPosition["x"] = [item["x"]]
            #     entryPosition["y"] = [item["y"]]
            #     entryPosition["z"] = [item["z"]]
            #     entryPosition["sequence"] = [item["sequence"]]
                
            #     df = pd.DataFrame.from_dict(entryPosition)
            #     # The entry except the first one has no need the header
            #     # self.append_df_to_excel(fileName, df, header=None, sheet_name='position', index=False)
            #     self.append_df_to_excel(fileName, df, header=None, sheet_name='position', index=False)
                            
                # self.append_df_to_excel(fileName, df, header=None, index=False)
                # with pd.ExcelWriter(fileName, mode="w", engine="openpyxl") as writer:
                #     df.to_excel(writer, sheet_name='sheet1')

                # writer.save()

                # with open(fileName, "a", encoding="utf-8-sig") as fd:
                #     writer = csv.DictWriter(fd, fieldnames=entryPosition.keys())
                #     writer.writerow(entryPosition)                

        elif(dataType == messageDataType.ANGLE_DATA):
            fileName = ''
            entryAngle = dict()
            if item["tag_id"] not in self.tagList:
                print('tag is not in the tagList')
                self.tagList.append(item["tag_id"])

            # Generate the csv file name
            fileName = "{}.xlsx".format(item["tag_id"])
            
            # Generate the entry and append to excel file
            entryAngle["azimuth"] = [item["azimuth"]]
            entryAngle["elevation"] = [item["elevation"]]
            entryAngle["distance"] = [item["distance"]]
            entryAngle["quality"] = [item["quality"]]
            entryAngle["sequence"] = [item["sequence"]]
            entryAngle["rssi"] = [item["rssi"]]

            # print("enterAngle: ")
            # print(entryAngle)

            # write = pd.ExcelWriter(fileName)
            # df = pd.DataFrame({"x":[item["x"]], "y":[item["y"]], "z":[item["z"]], "sequence":[item["sequence"]]})
            # df = pd.DataFrame.from_dict(entryAngle)
            
            # Use the locator id as the sheet name
            sheetName = str(item["loc_id"])
            self.append_df_to_excel(fileName, entryAngle, header=None, sheet_name=sheetName, index=False)

                # with pd.ExcelWriter(fileName, mode="w", engine="openpyxl") as writer:
                #     df.to_excel(writer, index=False, sheet_name='position')
                # df.to_excel(writer, 'sheet1')
                
                # writer.save()

                # with open(fileName, "a", encoding="utf-8-sig") as fd:
                #     writer = csv.DictWriter(fd, fieldnames=entryPosition.keys())
                #     writer.writeheader()
                #     writer.writerow(entryPosition)
            # else:
            #     # Generate the csv file name
            #     fileName = "{}.xlsx".format(item["tag_id"])
            #     self.tagList.append(item["tag_id"])
            #     # Generate the header
            #     # Write the first entry to the csv file
                
            #     entryAngle["azimuth"] = [item["azimuth"]]
            #     entryAngle["elevation"] = [item["elevation"]]
            #     entryAngle["distance"] = [item["distance"]]
            #     entryAngle["rssi"] = [item["rssi"]]
            #     entryAngle["channel"] = [item["channel"]]
            #     entryAngle["sequence"] = [item["sequence"]]

            #     print("enterAngle keys ......")
            #     print(entryAngle)

            #     # write = pd.ExcelWriter(fileName)
            #     # df = pd.DataFrame({"x":[item["x"]], "y":[item["y"]], "z":[item["z"]], "sequence":[item["sequence"]]})
            #     df = pd.DataFrame.from_dict(entryAngle)
                
            #     # Use the locator id as the sheet name
            #     sheetName = item["loc_id"]
            #     self.append_df_to_excel(fileName, df, header=None, sheet_name=sheetName, index=False)

        if(dataType == messageDataType.POSITION_DATA):
            fileName = ''
            entryPosition = dict()
            if item["tag_id"] not in self.tagList:
                print('tag is not in the tagList')
                raise AssertionError("tag is not in the tagList")
                
            # Generate the csv file name
            fileName = "ble-pd-position_all.xlsx"
            sheetName = str(item["tag_id"])
            str_now_time = time.strftime("%H-%M-%S", time.localtime(time.time()))
            # Generate the entry and append to excel file
            entryPosition["x"] = [item["x"]]
            entryPosition["y"] = [item["y"]]
            entryPosition["z"] = [item["z"]]
            entryPosition["sequence"] = [item["sequence"]]
            entryPosition["timeHMS"] = [str_now_time]

            # print("entryPosition: ")
            # print(entryPosition)

            self.append_df_to_excel(fileName, entryPosition, header=None, sheet_name=sheetName, index=False)

    def append_df_to_excel(self, filename, payload, sheet_name='Sheet1', startrow=None, **to_excel_kwargs):
        """
        Append a DataFrame [df] to existing Excel file [filename]
        into [sheet_name] Sheet.
        If [filename] doesn't exist, then this function will create it.

        @param filename: File path or existing ExcelWriter
                        (Example: '/path/to/file.xlsx')
        @param df: DataFrame to save to workbook
        @param sheet_name: Name of sheet which will contain DataFrame.
                        (default: 'Sheet1')
        @param startrow: upper left cell row to dump data frame.
                        Per default (startrow=None) calculate the last row
                        in the existing DF and write to the next row...
        @param truncate_sheet: truncate (remove and recreate) [sheet_name]
                            before writing DataFrame to Excel file
        @param to_excel_kwargs: arguments which will be passed to `DataFrame.to_excel()`
                                [can be a dictionary]
        @return: None

        Usage examples:

        >>> append_df_to_excel('d:/temp/test.xlsx', df)

        >>> append_df_to_excel('d:/temp/test.xlsx', df, header=None, index=False)

        >>> append_df_to_excel('d:/temp/test.xlsx', df, sheet_name='Sheet2',
                            index=False)

        >>> append_df_to_excel('d:/temp/test.xlsx', df, sheet_name='Sheet2', 
                            index=False, startrow=25)

        (c) [MaxU](https://stackoverflow.com/users/5741205/maxu?tab=profile)
        """
        self.lock.acquire(False)

        # Excel file doesn't exist - saving and exiting
        # if not os.path.isfile(filename):
        currentPath = os.path.dirname(os.path.realpath(__file__))
        fullFileName = str(currentPath)+'/'+str(filename)

        # print("fileName:" + fullFileName + " sheet:" + sheet_name)
        df = pd.DataFrame.from_dict(payload)

        # if the file doesn't exist, create it
        if not os.path.exists(fullFileName):
            # For the first time create file and sheet, remove the header parameter, it will store the header information then.
            if 'header' in to_excel_kwargs:
                to_excel_kwargs.pop('header')

            df.to_excel(
                filename,
                sheet_name=sheet_name, 
                startrow=startrow if startrow is not None else 0, 
                **to_excel_kwargs)
            
            self.lock.release()
            return


        # self.dfList store the dfHandler for each sheet
        # And it will only write the excel file periodically.
        dfName = filename+sheet_name
        # print(self.dfDict)
        dfHandler = self.dfDict.get(dfName)

        if self.dfDict.get(dfName) is None:
            self.dfDict[dfName] = pd.DataFrame.from_dict(payload)
        else:
            self.dfDict[dfName] = self.dfDict[dfName].append(df)

        # print('current ->->->->--------')
        # print(self.dfDict[dfName])
        # print(len(self.dfDict[dfName]))
        # print('\n')
        # random write interval to avoid if multi sheet write consequently.
        excelWriteInterval = random.randint(90, 100)

        if((self.dfDict.get(dfName) is not None) and (len(self.dfDict[dfName]) >= excelWriteInterval)):
            # ignore [engine] parameter if it was passed
            if 'engine' in to_excel_kwargs:
                to_excel_kwargs.pop('engine')

            writer = pd.ExcelWriter(filename, engine='openpyxl', mode='a')

            # try to open an existing workbook
            writer.book = openpyxl.load_workbook(filename)
            
            # get the last row in the existing Excel sheet
            # if it was not specified explicitly
            if startrow is None and sheet_name in writer.book.sheetnames:
                startrow = writer.book[sheet_name].max_row
                print('startrow is: ')
                print(startrow)

            # # truncate sheet
            # if truncate_sheet and sheet_name in writer.book.sheetnames:
            #     # index of [sheet_name] sheet
            #     idx = writer.book.sheetnames.index(sheet_name)
            #     # remove [sheet_name]
            #     writer.book.remove(writer.book.worksheets[idx])
            #     # create an empty sheet [sheet_name] using old index
            #     writer.book.create_sheet(sheet_name, idx)

            # The default header parameter is None, so it will not write the header
            # In the case of first write, remove the header parameter, it will store the header information then.
            # print("+++++++++++++++++++++++++------------------------------------------------------")
            print(' Write entries to file&sheet %s_%s' % (filename, sheet_name))
            # print(writer.book.sheetnames)

            if sheet_name not in writer.book.sheetnames:
                # print("<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>")
                if 'header' in to_excel_kwargs:
                    to_excel_kwargs.pop('header')

            # print(to_excel_kwargs)

            # copy existing sheets
            writer.sheets = {ws.title:ws for ws in writer.book.worksheets}

            if startrow is None:
                startrow = 0

            # write out the new sheet
            self.dfDict[dfName].to_excel(writer, sheet_name=sheet_name, startrow=startrow, **to_excel_kwargs)

            # save the workbook
            writer.save()
            writer.close()

            # Clear the dataframe after finishing the excel writing
            self.dfDict[dfName] = df[0:0]
            print('write this entry done --->>> \n\n')

        self.lock.release()

