/***************************************************************************//**
 * @file
 * @brief Default AoA Configuration.
 *******************************************************************************
 * # License
 * <b>Copyright 2020 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/

#ifndef AOA_CONFIG_H
#define AOA_CONFIG_H

#include "aoa_types.h"
//#include "mqtt.h"

#define AOA_TOPIC_ANGLE_PRINT    "silabs/aoa/angle/%s/%s"
#define AOA_TOPIC_ANGLE_SCAN     "silabs/aoa/angle/%64[^/]/%64[^/]"
#define AOA_TOPIC_POSITION_PRINT "silabs/aoa/position/%s/%s"
#define AOA_TOPIC_POSITION_SCAN  "silabs/aoa/position/%64[^/]/%64[^/]"

//void aoa_on_connect(mqtt_handle_t *handle);
void aoa_angle_to_string(aoa_angle_t *angle, char** str);
void aoa_string_to_angle(char* str, aoa_angle_t *angle);
void aoa_position_to_string(aoa_position_t *position, char** str);
void aoa_string_to_position(char* str, aoa_position_t *position);

#endif // AOA_CONFIG_H
