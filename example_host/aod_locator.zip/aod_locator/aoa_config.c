/***************************************************************************//**
 * @file
 * @brief Default AoA Configuration.
 *******************************************************************************
 * # License
 * <b>Copyright 2020 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/

#include "aoa_config.h"
#include "aoa_serdes.h"
#include "cJSON.h"

//void aoa_on_connect(mqtt_handle_t *handle)
//{
//  // Nothing to do.
//}

void aoa_angle_to_string(aoa_angle_t *angle, char** str)
{
  cJSON *root = cJSON_CreateObject();
  aoa_serialize_angle(angle, root);
  *str = cJSON_Print(root);
  cJSON_Delete(root);
}

void aoa_string_to_angle(char* str, aoa_angle_t *angle)
{
  cJSON *root = cJSON_Parse(str);
  aoa_deserialize_angle(root, angle);
  cJSON_Delete(root);
}

void aoa_position_to_string(aoa_position_t *position, char** str)
{
  cJSON *root = cJSON_CreateObject();
  aoa_serialize_position(position, root);
  *str = cJSON_Print(root);
  cJSON_Delete(root);
}

void aoa_string_to_position(char* str, aoa_position_t *position)
{
  cJSON *root = cJSON_Parse(str);
  aoa_deserialize_position(root, position);
  cJSON_Delete(root);
}
